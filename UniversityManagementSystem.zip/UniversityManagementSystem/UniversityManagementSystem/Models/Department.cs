﻿namespace UniversityManagementSystem.Models
{
    public class Department
    {
        public int DepartmentId { set; get; }
        public string DepartmentCode { set; get; }
        public string DepartmentName { set; get; }
    }
}