
$(document).ready(function(){/* jQuery toggle layout */
	$('#btnToggle').click(function(){
	  if ($(this).hasClass('on')) {
		$('#main .col-md-6').addClass('col-md-4').removeClass('col-md-6');
		$(this).removeClass('on');
	  }
	  else {
		$('#main .col-md-4').addClass('col-md-6').removeClass('col-md-4');
		$(this).addClass('on');
	  }
	});
	
	/*clock*/
	function ShowCurrentTime() {
		var dt = new Date();
		document.getElementById("lblTime").innerHTML = dt.toLocaleTimeString();
		window.setTimeout("ShowCurrentTime()", 1000); // Here 1000(milliseconds) means one 1 Sec  
	}
	
});
